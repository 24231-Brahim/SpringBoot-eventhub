package com.eventhub.event_booking_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventBookingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventBookingBackendApplication.class, args);
	}

}
